import os
from groq import Groq

class MissingAPIKeyError(Exception):
    pass

class GroqServiceError(Exception):
    pass

def generate_message(prompt: str) -> str:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise MissingAPIKeyError()

    # Set GROQ_MODEL in .env if your Groq account uses a different supported model.
    model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    try:
        client = Groq(api_key=api_key)
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a careful writing assistant. Follow the user's instructions exactly."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.6,
            max_tokens=1200,
        )
        content = response.choices[0].message.content
        if not content or not content.strip():
            raise GroqServiceError("The AI returned an empty response.")
        return content.strip()
    except MissingAPIKeyError:
        raise
    except Exception as exc:
        raise GroqServiceError(str(exc)) from exc
