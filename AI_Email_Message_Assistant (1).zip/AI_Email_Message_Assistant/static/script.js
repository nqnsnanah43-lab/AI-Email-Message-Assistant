const messageInput = document.getElementById("message");
const messageType = document.getElementById("messageType");
const tone = document.getElementById("tone");
const generateBtn = document.getElementById("generateBtn");
const errorMessage = document.getElementById("errorMessage");
const emptyState = document.getElementById("emptyState");
const loadingState = document.getElementById("loadingState");
const generatedText = document.getElementById("generatedText");
const outputActions = document.getElementById("outputActions");
const outputStatus = document.getElementById("outputStatus");
let lastRequest = null;

messageInput.addEventListener("input", () => {
  document.getElementById("charCount").textContent = messageInput.value.length;
  errorMessage.textContent = "";
});

function setLoading(isLoading) {
  generateBtn.disabled = isLoading;
  generateBtn.querySelector("span:first-child").textContent = isLoading ? "Generating..." : "Generate with AI";
  loadingState.classList.toggle("hidden", !isLoading);
  if (isLoading) {
    emptyState.classList.add("hidden");
    generatedText.classList.add("hidden");
    outputActions.classList.add("hidden");
    outputStatus.textContent = "WORKING";
  }
}

async function generate(isRegenerate = false) {
  const message = messageInput.value.trim();
  if (!message) {
    errorMessage.textContent = "Please enter your message.";
    messageInput.focus();
    return;
  }

  lastRequest = {
    message,
    message_type: messageType.value,
    tone: tone.value
  };
  errorMessage.textContent = "";
  setLoading(true);

  try {
    const response = await fetch("/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(lastRequest)
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      throw new Error(data.error || "Something went wrong. Please try again.");
    }
    generatedText.textContent = data.generated_message;
    generatedText.classList.remove("hidden");
    emptyState.classList.add("hidden");
    outputActions.classList.remove("hidden");
    outputStatus.textContent = "GENERATED";
  } catch (error) {
    errorMessage.textContent = error.message || "Unable to connect to the AI service.";
    generatedText.classList.add("hidden");
    emptyState.classList.remove("hidden");
    outputStatus.textContent = "ERROR";
  } finally {
    setLoading(false);
  }
}

generateBtn.addEventListener("click", () => generate());
document.getElementById("regenerateBtn").addEventListener("click", () => {
  if (lastRequest) generate(true);
});
document.getElementById("copyBtn").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(generatedText.textContent);
    const button = document.getElementById("copyBtn");
    button.innerHTML = "✓ <span>Copied</span>";
    setTimeout(() => { button.innerHTML = "▢ <span>Copy</span>"; }, 1600);
  } catch {
    errorMessage.textContent = "Copy failed. Please select and copy the text manually.";
  }
});
document.getElementById("downloadBtn").addEventListener("click", () => {
  const blob = new Blob([generatedText.textContent], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "improved-message.txt";
  link.click();
  URL.revokeObjectURL(url);
});
document.getElementById("clearBtn").addEventListener("click", () => {
  messageInput.value = "";
  document.getElementById("charCount").textContent = "0";
  generatedText.textContent = "";
  generatedText.classList.add("hidden");
  outputActions.classList.add("hidden");
  loadingState.classList.add("hidden");
  emptyState.classList.remove("hidden");
  errorMessage.textContent = "";
  outputStatus.textContent = "READY";
  lastRequest = null;
});
messageInput.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") generate();
});
