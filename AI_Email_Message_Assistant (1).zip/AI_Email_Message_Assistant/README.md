# AI Email & Message Assistant

A beginner-friendly Flask web app that improves rough messages using the Groq API.

## Features
- Professional Email, Student Message, Leave Application, and Formal Request
- Professional, Polite, and Friendly tones
- Real Groq API generation
- Frontend and backend validation
- Copy, download, regenerate, and clear controls
- Loading and error messages
- Responsive layout

## Requirements
- Python 3.10+
- A Groq API key from https://console.groq.com/

## Windows setup (VS Code)

1. Open this folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Create a virtual environment:

   ```bash
   py -m venv venv
   ```

4. Activate it:

   ```bash
   venv\Scripts\activate
   ```

5. Install packages:

   ```bash
   py -m pip install -r requirements.txt
   ```

6. Make a copy of `.env.example` and name the copy `.env`.
7. Open `.env` and replace the sample value with your real Groq API key:

   ```env
   GROQ_API_KEY=your_actual_key_here
   GROQ_MODEL=llama-3.3-70b-versatile
   ```

   If this model is not available to your account, replace `GROQ_MODEL` with a currently supported model shown in your Groq Console.

8. Start the app:

   ```bash
   py app.py
   ```

9. Open this address in Chrome:

   http://127.0.0.1:5000

Keep the terminal running while you use the website. Press `Ctrl+C` in the terminal to stop the server.

## Important security note
Never upload `.env` or your real API key to GitHub. The `.gitignore` file excludes `.env`. Upload `.env.example` instead.

## Project structure

```text
AI_Email_Message_Assistant/
├── app.py
├── groq_service.py
├── prompts.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```
