def build_prompt(message_type: str, tone: str, rough_message: str) -> str:
    return f"""
Improve the user's rough text as a {message_type}.
Writing tone: {tone}.

Instructions:
- Correct spelling and grammar.
- Improve clarity and sentence structure.
- Preserve the original meaning and all known facts.
- Do not invent names, dates, reasons, deadlines, or other information.
- Use a suitable format for the selected message category.
- For a professional email, include a short subject line when appropriate.
- Return only the improved message. Do not explain your changes.

Rough message:
{rough_message}
""".strip()
