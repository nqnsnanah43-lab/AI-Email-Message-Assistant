from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from prompts import build_prompt
from groq_service import generate_message, MissingAPIKeyError, GroqServiceError

load_dotenv()
app = Flask(__name__)

MESSAGE_TYPES = ["Professional Email", "Student Message", "Leave Application", "Formal Request"]
TONES = ["Professional", "Polite", "Friendly"]

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    message_type = str(data.get("message_type", "")).strip()
    tone = str(data.get("tone", "")).strip()

    if not message:
        return jsonify(success=False, error="Please enter your message."), 400
    if len(message) > 10000:
        return jsonify(success=False, error="Please keep your message under 10,000 characters."), 400
    if message_type not in MESSAGE_TYPES:
        return jsonify(success=False, error="Please select a valid message type."), 400
    if tone not in TONES:
        return jsonify(success=False, error="Please select a valid writing tone."), 400

    try:
        prompt = build_prompt(message_type, tone, message)
        result = generate_message(prompt)
        return jsonify(success=True, generated_message=result)
    except MissingAPIKeyError:
        return jsonify(success=False, error="Groq API key is missing. Add it to your .env file."), 503
    except GroqServiceError as exc:
        app.logger.error("Groq service error: %s", exc)
        return jsonify(success=False, error="Unable to connect to the AI service. Please check your settings and try again."), 502
    except Exception:
        app.logger.exception("Unexpected generation error")
        return jsonify(success=False, error="Something went wrong. Please try again."), 500

if __name__ == "__main__":
    app.run(debug=True)
